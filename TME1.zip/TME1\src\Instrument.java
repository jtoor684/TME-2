public abstract class Instrument {
    void adjust() {
        System.out.println(this + " adjust");
    }
}
