public class Brass extends Wind {
    public String toString() {
        return "Brass";
    }
}
