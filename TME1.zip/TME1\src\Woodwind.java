public class Woodwind extends Wind {
    public String toString() {
        return "Woodwind";
    }
}
