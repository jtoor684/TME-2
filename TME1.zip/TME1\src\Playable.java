public interface Playable {
    void play(Note n);
}
